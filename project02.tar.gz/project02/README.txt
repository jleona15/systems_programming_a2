
I was unable to complete this project fully within time constraints, though my current iteration does have some of the desired functionality.

My program can encode messages using several copies of a single message,
I could not succesfully create a version that that uses several images and
loops back through once the last available image is full.

My program can decode messages encoded this way, but I was unable to allow
the user to specify the desired output directory.

Currently my program is invoked in the same way as project01, but it will
use multiple threads to encode or decode the message, and supports decoding
from multiple messages by passing the "base" file name of the file to decode.
For example, if "foo.ppm" is passed in, it will look for "foo-0.ppm",
"foo-1.ppm", "foo-2.ppm", etc., until there are no files in this sequence to
decode.
