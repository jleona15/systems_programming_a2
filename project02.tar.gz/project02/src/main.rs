use std::env;

use std::fs;
use std::fs::File;
use std::io::{Read, Write};
use std::thread;
use std::sync::mpsc;
use std::sync::mpsc::{Sender, Receiver};
//use std::mem::size_of;
use std::time;
use std::process::exit;

fn thread_encode(img: &str, thread_msg: String, thread_id: i32, last_thread: bool, tx: Sender<i32>, thread_index: i32) -> i32 {
    let output = File::create(format!("{}{}{}", "out-", thread_id, ".ppm"));
    
    let mut output = output.unwrap();

    let thread_msg = &thread_msg[..];

    let input = File::open(img);
    let mut input = input.unwrap();

    let mut buff = [0u8;1];

    let mut chars = thread_msg.chars();

    let mut newline_count = 0;

    loop {
        if input.read(&mut buff).unwrap() == 0 {
            return -1;
        }
        let result = output.write(&mut buff);

        match result  {
            Result::Err(err) => {
                    eprintln!("File write error: {:?}", err);
                    return -1;
                },
                Result::Ok(ok) => ok,
            };

            if buff[0] as char == '\n' {
                //println!("Found new line!");
                newline_count += 1;
                if newline_count == 3 {
                    break;
                }
            }
        }   

        let mut bit_count = 0;
        let mut char_temp: u8;
        let mut unwrap_temp: Option<char>;
        let mut last_flag = false;

        unwrap_temp = chars.next();
            if unwrap_temp == None {
                char_temp = '\0' as u8;
                last_flag = true;
            } else {
                char_temp = unwrap_temp.unwrap() as u8;
        }
        if last_thread == true {
            loop {
                input.read(&mut buff).unwrap();

                buff[0] = ((buff[0] >> 1) << 1) | ((char_temp >> (7 - bit_count)) & 1);

                let result = output.write(&mut buff);

                match result  {
                    Result::Err(err) => {
                        eprintln!("File write error: {:?}", err);
                            return -1;
                    },
                    Result::Ok(ok) => ok,
                };

                bit_count += 1;

                if bit_count == 8 {
                    if last_flag == true {
                        break;
                    }
                    bit_count = 0;
                    unwrap_temp = chars.next();
                    if unwrap_temp == None {
                        char_temp = '\0' as u8;
                        last_flag = true;
                    } else {
                        char_temp = unwrap_temp.unwrap() as u8;
                    }
                }
            }
        }

        loop {
            let num_read = input.read(&mut buff).unwrap();

            if num_read == 0 {
                break;
            }

            let result = output.write(&mut buff);

            match result {
                Result::Err(err) => {
                    eprintln!("File write error: {:?}", err);
                    return -1;
                },
                Result::Ok(ok) => ok,
            };
        }
            
        tx.send(thread_index).unwrap();                  
        return 0;
}

fn thread_decode(image_capacity: usize, mut input: fs::File, thread_id: i32, tx: Sender<(i32, i32, String)>, thread_index: i32) -> i32 {
    let mut string = String::from("");

    let mut buff = [0u8;1];
    //let mut result: usize;

    let mut newline_count = 0;

    loop {
        //print!("a"); 
        input.read(&mut buff).unwrap();

        // 10 is just the ASCII value for newline
        if buff[0] as char == '\n' {
            //println!("Found new line!");
            newline_count += 1;
            if newline_count == 3 {
                //println!("BREAKING");
                break;
            }
        }        
    }
    //println!("BROKE");

    let mut bit_count = 0;
    let mut bit_accumulator = 0;

    for _i in 0..image_capacity {
        input.read(&mut buff).unwrap();

        bit_count += 1;
        bit_accumulator = (bit_accumulator << 1) | (buff[0] & 1);

        if bit_count == 8 {
            bit_count = 0;
            if bit_accumulator == ('\0' as u8) {
                break;
            }
            string.push(bit_accumulator as char);
            bit_accumulator = 0;
        }
    }     

    //println!("{}", string);

    match tx.send((thread_index, thread_id, string)) {
        Ok(_) => {},//println!("Message sent!"),
        Err(_) => {},//println!("Message error"),
    }

    return 0;
}

// Encodes the message, msg, into the image specified by the path img
fn encode(img: &str, msg: &str) {
    //println!("Main thread started!");
    
    let num_threads = 10;

    let mut msg = String::from(msg);

    //println!("Opening {}...", img);

    let input = File::open(img);

    match &input {
        Result::Err(err) => {
            eprintln!("Error, specified file could not be opened: {}", err);
            return;
        },
        Result::Ok(ok) => ok,
    };

    //let mut msg = msg.chars();

    let metadata = fs::metadata(img).unwrap();

    let image_capacity: usize = ((metadata.len() - 13) / 8) as usize;
    
    //if ((metadata.len() as i64 - 13) % 8) != 0 {
    //   image_capacity += 1
    //}

    //let mut num_images = msg.len() as usize / image_capacity;

    //if (((msg.len() as usize) + 1) % image_capacity) != 0 {
    //    num_images += 1;
    //}

    let mut thread_list = Vec::new();

    //thread_list.reserve(num_threads * size_of::<Option<std::thread::JoinHandle::<i32>>>());

    for _i in 0..num_threads {
        let temp: Option<std::thread::JoinHandle::<i32>> = None;
        thread_list.push(temp);
    }

    let mut to_spawn: i32;
    let mut thread_id: i32 = 0;

    let mut last_thread = false;

    //println!("Image capacity: {}", image_capacity);

    let (tx, rx): (Sender<i32>, Receiver<i32>) = mpsc::channel();

    //println!("Thread monitoring loop started!");
    loop {
        //println!("{}", last_thread);
        if last_thread == true {
            //println!("BREAKING!");
            break;
        }

        to_spawn = match rx.try_recv() {
            Result::Ok(ok) => ok,
            Result::Err(_) => -1,
        }; 

        if to_spawn == -1 {
            for i in 0..num_threads {
                match thread_list[i] {
                    None => {
                        to_spawn = i as i32;

                        break;
                    }
                    Some(_) => (),
                }
            }
        }

        if to_spawn == -1 {
            thread::sleep(time::Duration::from_millis(5));
        } else {
            //println!("Started thread setup operations...");
            let thread_index = to_spawn;

            let tx = tx.clone();

            let curr_thread_id = thread_id;

            let thread_msg: String;

            if msg.len() + 1 < image_capacity {
                //This flag will tell the last thread to output the
                //  null char to the image
                //println!("Last thread to spawn, next loop should break!");
                last_thread = true;
                thread_msg = msg[..].to_string();
            } else {
                //Split the string, giving a portion to the thread
                thread_msg = msg[0..image_capacity].to_string();
                msg = String::from(&msg[image_capacity..(msg.len() as usize)]);
            }

            let img = img.to_owned();

            //println!("Thread {} spawned with message \"{}\"", thread_id, thread_msg);
            thread_list[to_spawn as usize] = Some(thread::spawn(move || thread_encode(&img, thread_msg, curr_thread_id, last_thread, tx, thread_index)));
            
            thread_id += 1;
        }       
    }

    //Wait for all running threads to finish
    for _i in 0..num_threads {
        let temp = thread_list.swap_remove(0);

        match temp {
            Some(handle) => {
                //thread_list[i] = None;
                match handle.join() {
                    Ok(_) => {},
                    Err(_) => {
                        println!("Thread join error!");
                        exit(0);
                    } 
                }
            },
            None => {},
        };
    }

    println!("Message \"{}\" successfully written to local files", msg);
}

// Decodes a hidden message from the image specified by img, returning the
// message as a string
fn decode(img: &str) {
    
    //println!("Main thread started!");
    
    let num_threads = 10;
    
    let mut thread_list = Vec::new();
    let mut str_vec: Vec<(i32, String)> = Vec::new();

    //thread_list.reserve(num_threads * size_of::<Option<std::thread::JoinHandle::<i32>>>());

    for _i in 0..num_threads {
        let temp: Option<std::thread::JoinHandle::<i32>> = None;
        thread_list.push(temp);
    }

    let mut to_spawn: i32;
    let mut thread_id: i32 = 0;

    let (tx, rx): (Sender<(i32, i32, String)>, Receiver<(i32, i32, String)>) = mpsc::channel();

    //println!("Thread monitoring loop started!");
    loop {
        to_spawn = match rx.try_recv() {
            Result::Ok(ok) => {
                let mut inserted = false;
                for i in 0..str_vec.len() {
                    if ok.1 < str_vec[i].0 {
                        str_vec.insert(i, (ok.1, ok.2.clone()));
                        inserted = true;
                        break;
                    }
                }

                if inserted == false {
                    str_vec.push((ok.1, ok.2));
                }

                ok.0
            },
            Result::Err(_) => -1,
        }; 

        if to_spawn == -1 {
            for i in 0..num_threads {
                match thread_list[i] {
                    None => {
                        to_spawn = i as i32;

                        break;
                    }
                    Some(_) => (),
                }
            }
        }

        if to_spawn == -1 {
            thread::sleep(time::Duration::from_millis(5));
        } else {
            //println!("Pre threadspawn");
 
            let temp_str = String::from(img);

            //println!("{}{}{}{}", temp_str.split_at(temp_str.find(".").unwrap()).0, "-", thread_id, ".ppm");

            let input = File::open(format!("{}{}{}{}", temp_str.split_at(temp_str.find(".").unwrap()).0, "-", thread_id, ".ppm"));

            let break_flag = match &input {
                Result::Err(_) => {
                    //println!("File not found..."); 
                    true
                },
                Result::Ok(_) => false,
            };

            if break_flag {
                break;
            }

            let metadata = fs::metadata(format!("{}{}{}{}", temp_str.split_at(temp_str.find(".").unwrap()).0, "-", thread_id, ".ppm")).unwrap();

            let image_capacity: usize = ((metadata.len() - 13) / 8) as usize;
            
            //println!("Started thread setup operations...");
            let thread_index = to_spawn;

            let tx = tx.clone();

            let curr_thread_id = thread_id;

            //let img = img.to_owned();

            thread_list[to_spawn as usize] = Some(thread::spawn(move || thread_decode(image_capacity, input.unwrap(), curr_thread_id, tx, thread_index)));
            
            thread_id += 1;
        }       
    }

    //Wait for all running threads to finish
    for _i in 0..num_threads {
         

        let temp = thread_list.swap_remove(0);

        match temp {
            Some(handle) => {
                //thread_list[i] = None;
                match handle.join() {
                    Ok(_) => {},
                    Err(_) => {
                        println!("Error on thread join!");
                        exit(0);
                    },
                }
            },
            None => {},
        }; 
    }

    loop {
        match rx.try_recv() {
            Result::Ok(ok) => {
                let mut inserted = false;
                for i in 0..str_vec.len() {
                    if ok.1 < str_vec[i].0 {
                        str_vec.insert(i, (ok.1, ok.2.clone()));
                        inserted = true;
                        break;
                    }
                }

                if inserted == false {
                    str_vec.push((ok.1, ok.2));
                }
            },
            Result::Err(_) => {
                break;
            }
        };
    }

    //println!("Trying to output");

    //println!("Len: {}", str_vec.len());

    for i in 0..str_vec.len() {
        println!("{}", str_vec[i].1);
    }
}

fn main() {
    // Obtains the command line arguments
    let args: Vec<String> = env::args().collect();

    if args.len() < 3 || args.len() > 4 {
        eprintln!("Error: Program requires one or two input arguments");
    }

    if args.len() == 3 {
        decode(&args[2]);
    }

    if args.len() == 4 {
        encode(&args[2], &args[3]);
    }
}
